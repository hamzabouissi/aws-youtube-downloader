import pymongo
import os

mongo_host = os.environ['MONGO_HOST']
mongo_db = 'youtubeVideos'
mongo_uri = 'mongodb://crawler:youtube_videos@mongo_host:27017/?authSource=admin'
SUBTITLES_BUCKET_NAME='youtubecrawledsubtitles'

def handler(event, context):
    client = pymongo.MongoClient(mongo_uri)   
    db = client[mongo_db]
    for item in event['Records']:
        db[item['video_id']].insert_one({
            "video_id": item['video_id'],
            "parent_video_id": item['parent_video_id'],
            "subtitles":f"https://{SUBTITLES_BUCKET_NAME}.s3.amazonaws.com/{item['video_id']}"
        })
    return 'success'